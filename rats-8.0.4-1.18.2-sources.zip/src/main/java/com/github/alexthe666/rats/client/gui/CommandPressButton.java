package com.github.alexthe666.rats.client.gui;

import net.minecraft.network.chat.TextComponent;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

public class CommandPressButton extends Button {

	public CommandPressButton(int x, int y, Button.OnPress onPress) {
		super(x, y, 76, 16, new TextComponent(""), onPress, Button.NO_TOOLTIP);
	}

	@Override
	public void render(PoseStack matrixStack, int mouseX, int mouseY, float partialTicks) {
		if (this.visible) {
			boolean flag = mouseX >= this.x && mouseY >= this.y && mouseX < this.x + this.width && mouseY < this.y + this.height;
			RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
			RenderSystem.setShaderTexture(0, RatScreen.TEXTURE);
			int i = 0;
			int j = 177;
			if (flag) {
				j += 16;
			}

			blit(matrixStack, this.x, this.y, i, j, this.width, this.height);

		}
	}
}
