package com.github.alexthe666.rats.server.items.upgrades;

import com.github.alexthe666.rats.server.entity.rat.TamedRat;
import com.github.alexthe666.rats.server.items.upgrades.interfaces.DamageImmunityUpgrade;
import net.minecraft.world.damagesource.DamageSource;

public class ProtectionRatUpgradeItem extends BaseRatUpgradeItem implements DamageImmunityUpgrade {
	public ProtectionRatUpgradeItem(Properties properties) {
		super(properties, 2, 4);
	}

	@Override
	public boolean isImmuneToDamageSource(TamedRat rat, DamageSource source) {
		return source.isMagic() || source == DamageSource.WITHER || source.isFire() || source.isFall() || source == DamageSource.DROWN;
	}
}
