package com.github.alexthe666.rats.data.ratlantis.tags;

import com.github.alexthe666.rats.RatsMod;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.Block;

public class RatlantisBlockTags {
	public static final TagKey<Block> PIRAT_LOGS = TagKey.create(net.minecraft.core.Registry.BLOCK_REGISTRY, new ResourceLocation("rats:pirat_logs"));

	public static final TagKey<Block> PIRAT_ONLY_BLOCKS = TagKey.create(net.minecraft.core.Registry.BLOCK_REGISTRY, new ResourceLocation("rats:pirat_blocks"));

	public static final TagKey<Block> STORAGE_BLOCKS_ORATCHALCUM = TagKey.create(net.minecraft.core.Registry.BLOCK_REGISTRY, new ResourceLocation("forge:storage_blocks/oratchalcum"));

	public static final TagKey<Block> ORES_CHEESE = TagKey.create(net.minecraft.core.Registry.BLOCK_REGISTRY, new ResourceLocation("forge:ores/cheese"));

	public static final TagKey<Block> ORES_GEM_OF_RATLANTIS = TagKey.create(net.minecraft.core.Registry.BLOCK_REGISTRY, new ResourceLocation("forge:ores/gem_of_ratlantis"));

	public static final TagKey<Block> ORES_ORATCHALCUM = TagKey.create(net.minecraft.core.Registry.BLOCK_REGISTRY, new ResourceLocation("forge:ores/oratchalcum"));
}
