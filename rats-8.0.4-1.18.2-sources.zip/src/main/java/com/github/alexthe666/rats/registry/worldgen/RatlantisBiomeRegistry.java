package com.github.alexthe666.rats.registry.worldgen;

import com.github.alexthe666.rats.RatsMod;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeGenerationSettings;
import net.minecraft.world.level.biome.BiomeSpecialEffects;
import net.minecraft.world.level.biome.MobSpawnSettings;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Present in the biome registry before the Ratlantis datapack is parsed.
 * Weeping Angels 1.0.1 reads {@code ForgeRegistries.BIOMES.getValue(name)} from
 * {@code BiomeLoadingEvent} and crashes when that lookup is still null, which is
 * the case for a biome that only exists as JSON.
 */
public class RatlantisBiomeRegistry {
	public static final DeferredRegister<Biome> BIOMES = DeferredRegister.create(ForgeRegistries.BIOMES, RatsMod.MODID);
	public static final RegistryObject<Biome> RATLANTIS = BIOMES.register("ratlantis", RatlantisBiomeRegistry::create);

	private static Biome create() {
		return new Biome.BiomeBuilder()
				.precipitation(Biome.Precipitation.RAIN)
				.biomeCategory(Biome.BiomeCategory.JUNGLE)
				.temperature(0.55F)
				.downfall(0.5F)
				.specialEffects(new BiomeSpecialEffects.Builder()
						.fogColor(16767615)
						.foliageColorOverride(2546944)
						.grassColorOverride(8177920)
						.skyColor(16762410)
						.waterColor(4445678)
						.waterFogColor(270131)
						.build())
				.mobSpawnSettings(new MobSpawnSettings.Builder().creatureGenerationProbability(0.4F).build())
				.generationSettings(new BiomeGenerationSettings.Builder().build())
				.build();
	}
}
