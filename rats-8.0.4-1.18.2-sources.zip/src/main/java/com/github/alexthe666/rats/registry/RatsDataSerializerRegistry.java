package com.github.alexthe666.rats.registry;

import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.Registry;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.syncher.EntityDataSerializer;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class RatsDataSerializerRegistry {

	public static final EntityDataSerializer<Optional<GlobalPos>> OPTIONAL_GLOBAL_POS = new EntityDataSerializer<>() {
		@Override
		public void write(FriendlyByteBuf buf, Optional<GlobalPos> value) {
			buf.writeBoolean(value.isPresent());
			value.ifPresent(pos -> {
				buf.writeResourceLocation(pos.dimension().location());
				buf.writeBlockPos(pos.pos());
			});
		}

		@Override
		public Optional<GlobalPos> read(FriendlyByteBuf buf) {
			if (!buf.readBoolean()) {
				return Optional.empty();
			}
			ResourceLocation dimension = buf.readResourceLocation();
			BlockPos pos = buf.readBlockPos();
			return Optional.of(GlobalPos.of(ResourceKey.create(Registry.DIMENSION_REGISTRY, dimension), pos));
		}

		@Override
		public Optional<GlobalPos> copy(Optional<GlobalPos> value) {
			return value;
		}
	};

	public static final EntityDataSerializer<Optional<BlockState>> OPTIONAL_BLOCK_STATE = new EntityDataSerializer<>() {
		@Override
		public void write(FriendlyByteBuf buf, Optional<BlockState> value) {
			buf.writeBoolean(value.isPresent());
			value.ifPresent(state -> buf.writeNbt(NbtUtils.writeBlockState(state)));
		}

		@Override
		public Optional<BlockState> read(FriendlyByteBuf buf) {
			if (!buf.readBoolean()) {
				return Optional.empty();
			}
			return Optional.of(NbtUtils.readBlockState(buf.readNbt()));
		}

		@Override
		public Optional<BlockState> copy(Optional<BlockState> value) {
			return value;
		}
	};

	public static final EntityDataSerializer<List<GlobalPos>> GLOBAL_POS_LIST = new EntityDataSerializer<>() {
		@Override
		public void write(FriendlyByteBuf buf, List<GlobalPos> list) {
			buf.writeCollection(list, (out, pos) -> {
				out.writeResourceLocation(pos.dimension().location());
				out.writeBlockPos(pos.pos());
			});
		}

		@Override
		public List<GlobalPos> read(FriendlyByteBuf buf) {
			return buf.readList(in -> {
				ResourceLocation dimension = in.readResourceLocation();
				BlockPos pos = in.readBlockPos();
				return GlobalPos.of(ResourceKey.create(Registry.DIMENSION_REGISTRY, dimension), pos);
			});
		}

		@Override
		public List<GlobalPos> copy(List<GlobalPos> list) {
			return new ArrayList<>(list);
		}
	};
}
