package com.github.alexthe666.rats.compat.jei;

import net.minecraft.network.chat.TranslatableComponent;

import com.github.alexthe666.rats.RatsMod;
import com.github.alexthe666.rats.registry.RatsItemRegistry;
import com.github.alexthe666.rats.server.recipes.GemcutterRecipe;
import com.mojang.blaze3d.vertex.PoseStack;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.drawable.IDrawableAnimated;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

public class GemcutterRecipeCategory implements IRecipeCategory<GemcutterRecipe> {

	protected static final ResourceLocation TEXTURE = new ResourceLocation(RatsMod.MODID, "textures/gui/jei/gemcutter_rat_jei.png");
	private final IDrawable background;
	private final IDrawable icon;
	private final IDrawable arrow;

	public GemcutterRecipeCategory(IGuiHelper helper) {
		this.background = helper.createDrawable(TEXTURE, 3, 4, 170, 79);
		this.icon = helper.createDrawableItemStack(new ItemStack(RatsItemRegistry.TINY_COIN.get()));
		this.arrow = helper.drawableBuilder(TEXTURE, 176, 0, 24, 16)
				.buildAnimated(200, IDrawableAnimated.StartDirection.LEFT, false);
	}

	@Override
	public RecipeType<GemcutterRecipe> getRecipeType() {
		return RatsRecipeTypes.GEMCUTTER;
	}

	@Override
	public ResourceLocation getUid() {
		return new ResourceLocation(RatsMod.MODID, "gemcutter");
	}

	@Override
	public Class<? extends GemcutterRecipe> getRecipeClass() {
		return GemcutterRecipe.class;
	}

	@Override
	public Component getTitle() {
		return new TranslatableComponent("gui.rats.jei.gemcutting");
	}

	@Override
	public IDrawable getBackground() {
		return this.background;
	}

	@Override
	public IDrawable getIcon() {
		return this.icon;
	}

	@Override
	public void setRecipe(IRecipeLayoutBuilder builder, GemcutterRecipe recipe, IFocusGroup ingredients) {
		builder.addSlot(RecipeIngredientRole.INPUT, 43, 49).addIngredients(recipe.getIngredients().get(0));
		builder.addSlot(RecipeIngredientRole.OUTPUT, 114, 49).addItemStack(recipe.getResultItem());
	}

	@Override
	public void draw(GemcutterRecipe recipe, IRecipeSlotsView view, PoseStack stack, double mouseX, double mouseY) {
		this.arrow.draw(stack, 71, 49);
	}
}
