package com.github.alexthe666.rats.registry.worldgen;

import com.github.alexthe666.rats.RatsMod;
import com.github.alexthe666.rats.server.world.*;
import net.minecraft.core.Registry;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.carver.CaveCarverConfiguration;
import net.minecraft.world.level.levelgen.carver.WorldCarver;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.StructureFeature;
import net.minecraft.world.level.levelgen.feature.configurations.JigsawConfiguration;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureProcessor;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureProcessorType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

public class RatlantisFeatureRegistry {
	public static final DeferredRegister<WorldCarver<?>> CARVERS = DeferredRegister.create(ForgeRegistries.WORLD_CARVERS, RatsMod.MODID);
	public static final DeferredRegister<Feature<?>> FEATURES = DeferredRegister.create(ForgeRegistries.FEATURES, RatsMod.MODID);
	public static final DeferredRegister<StructureProcessorType<?>> PROCESSORS = DeferredRegister.create(Registry.STRUCTURE_PROCESSOR_REGISTRY, RatsMod.MODID);
	public static final DeferredRegister<StructureFeature<?>> STRUCTURES = DeferredRegister.create(ForgeRegistries.STRUCTURE_FEATURES, RatsMod.MODID);

	public static final RegistryObject<StructureFeature<JigsawConfiguration>> BARON_RUNWAY = STRUCTURES.register("baron_runway", () -> new RatsJigsawStructure(Heightmap.Types.OCEAN_FLOOR_WG));
	public static final RegistryObject<StructureFeature<JigsawConfiguration>> DUTCHRAT_SHIP = STRUCTURES.register("dutchrat_ship", () -> new RatsJigsawStructure(Heightmap.Types.WORLD_SURFACE_WG));

	public static final RegistryObject<WorldCarver<CaveCarverConfiguration>> RATLANTIS_CAVES = CARVERS.register("ratlantis_caves", () -> new RatsCaveCarver(CaveCarverConfiguration.CODEC));

	public static final RegistryObject<Feature<RatlantisRuinConfiguration>> RATLANTIS_RUIN = FEATURES.register("ratlantis_ruin", () -> new RatlantisRuinFeature(RatlantisRuinConfiguration.CODEC));
	public static final RegistryObject<Feature<NoneFeatureConfiguration>> MARBLE_PILE = FEATURES.register("marble_pile", () -> new MarblePileFeature(NoneFeatureConfiguration.CODEC));

	public static final RegistryObject<StructureProcessorType<CopyInputStateRuleProcessor>> COPY_STATE = registerProcessor("copy_state", () -> () -> CopyInputStateRuleProcessor.CODEC);

	private static <P extends StructureProcessor> RegistryObject<StructureProcessorType<P>> registerProcessor(String name, Supplier<StructureProcessorType<P>> factory) {
		return PROCESSORS.register(name, factory);
	}
}
