package com.github.alexthe666.rats.registry;

import net.minecraft.world.level.block.entity.BannerPattern;

/**
 * 1.18.2 stores banner patterns in an enum, so custom patterns cannot be registered.
 * These items still exist and apply the closest vanilla patterns.
 */
public class RatsBannerPatternRegistry {
	public static final BannerPattern RAT_PATTERN = BannerPattern.FLOWER;
	public static final BannerPattern CHEESE_PATTERN = BannerPattern.CIRCLE_MIDDLE;
	public static final BannerPattern RAT_AND_CROSSBONES_BANNER = BannerPattern.SKULL;
	public static final BannerPattern RAT_AND_SICKLE_BANNER = BannerPattern.MOJANG;
}
