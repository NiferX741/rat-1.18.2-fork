package com.github.alexthe666.rats.data.ratlantis.tags;

import com.github.alexthe666.rats.data.tags.RatsEntityTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;

public class RatlantisEntityTags {
	public static final TagKey<EntityType<?>> RATLANTEAN = RatsEntityTags.create("ratlantean");
}
