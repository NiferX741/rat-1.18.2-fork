package com.github.alexthe666.rats.registry;

import com.github.alexthe666.rats.RatsMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.biome.MobSpawnSettings;
import net.minecraftforge.event.world.BiomeLoadingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Set;

@Mod.EventBusSubscriber(modid = RatsMod.MODID)
public class RatsBiomeModifierRegistry {

	private static final Set<ResourceLocation> RAT_BIOMES = Set.of(
			new ResourceLocation("plains"), new ResourceLocation("sunflower_plains"), new ResourceLocation("snowy_plains"),
			new ResourceLocation("desert"), new ResourceLocation("swamp"), new ResourceLocation("forest"),
			new ResourceLocation("flower_forest"), new ResourceLocation("birch_forest"), new ResourceLocation("dark_forest"),
			new ResourceLocation("old_growth_birch_forest"), new ResourceLocation("old_growth_pine_taiga"), new ResourceLocation("old_growth_spruce_taiga"),
			new ResourceLocation("taiga"), new ResourceLocation("snowy_taiga"), new ResourceLocation("savanna"),
			new ResourceLocation("savanna_plateau"), new ResourceLocation("windswept_hills"), new ResourceLocation("windswept_gravelly_hills"),
			new ResourceLocation("windswept_forest"), new ResourceLocation("windswept_savanna"), new ResourceLocation("jungle"),
			new ResourceLocation("sparse_jungle"), new ResourceLocation("bamboo_jungle"), new ResourceLocation("badlands"),
			new ResourceLocation("eroded_badlands"), new ResourceLocation("wooded_badlands"), new ResourceLocation("meadow"),
			new ResourceLocation("grove"), new ResourceLocation("stony_peaks"), new ResourceLocation("jagged_peaks"),
			new ResourceLocation("beach"), new ResourceLocation("snowy_beach"), new ResourceLocation("stony_shore"),
			new ResourceLocation("dripstone_caves"), new ResourceLocation("lush_caves")
	);
	private static final Set<ResourceLocation> PIPER_BIOMES = Set.of(
			new ResourceLocation("swamp"), new ResourceLocation("forest"), new ResourceLocation("flower_forest"),
			new ResourceLocation("birch_forest"), new ResourceLocation("dark_forest"), new ResourceLocation("old_growth_birch_forest"),
			new ResourceLocation("old_growth_pine_taiga"), new ResourceLocation("old_growth_spruce_taiga"), new ResourceLocation("taiga"),
			new ResourceLocation("snowy_taiga"), new ResourceLocation("savanna"), new ResourceLocation("savanna_plateau"),
			new ResourceLocation("windswept_hills"), new ResourceLocation("windswept_gravelly_hills"), new ResourceLocation("windswept_forest"),
			new ResourceLocation("windswept_savanna"), new ResourceLocation("meadow"), new ResourceLocation("grove"),
			new ResourceLocation("beach"), new ResourceLocation("snowy_beach")
	);
	private static final Set<ResourceLocation> DEMON_BIOMES = Set.of(
			new ResourceLocation("basalt_deltas"), new ResourceLocation("nether_wastes"), new ResourceLocation("crimson_forest")
	);

	@SubscribeEvent
	public static void onBiomeLoad(BiomeLoadingEvent event) {
		ResourceLocation name = event.getName();
		if (name == null) {
			return;
		}
		if (RAT_BIOMES.contains(name)) {
			event.getSpawns().addSpawn(MobCategory.CREATURE, new MobSpawnSettings.SpawnerData(RatsEntityRegistry.RAT.get(), 80, 1, 3));
		}
		if (PIPER_BIOMES.contains(name)) {
			event.getSpawns().addSpawn(MobCategory.MONSTER, new MobSpawnSettings.SpawnerData(RatsEntityRegistry.PIED_PIPER.get(), 25, 1, 1));
		}
		if (DEMON_BIOMES.contains(name)) {
			event.getSpawns().addSpawn(MobCategory.MONSTER, new MobSpawnSettings.SpawnerData(RatsEntityRegistry.DEMON_RAT.get(), 15, 1, 1));
		}
	}
}
