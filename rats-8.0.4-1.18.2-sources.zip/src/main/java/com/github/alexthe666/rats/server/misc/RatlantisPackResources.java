package com.github.alexthe666.rats.server.misc;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.AbstractPackResources;
import net.minecraft.server.packs.PackResources;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.metadata.MetadataSectionSerializer;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class RatlantisPackResources implements PackResources {
	private final Path root;

	public RatlantisPackResources(Path root) {
		this.root = root;
	}

	private Path resolve(String path) {
		Path resolved = this.root;
		for (String part : path.split("/")) {
			if (!part.isEmpty() && !part.equals(".") && !part.equals("..")) {
				resolved = resolved.resolve(part);
			}
		}
		return resolved;
	}

	@Override
	public InputStream getRootResource(String name) throws IOException {
		Path path = this.resolve(name);
		if (!Files.exists(path)) {
			throw new IOException(name);
		}
		return Files.newInputStream(path);
	}

	@Override
	public InputStream getResource(PackType type, ResourceLocation location) throws IOException {
		return this.getRootResource(type.getDirectory() + "/" + location.getNamespace() + "/" + location.getPath());
	}

	@Override
	public boolean hasResource(PackType type, ResourceLocation location) {
		return Files.exists(this.resolve(type.getDirectory() + "/" + location.getNamespace() + "/" + location.getPath()));
	}

	@Override
	public Set<String> getNamespaces(PackType type) {
		Set<String> namespaces = new HashSet<>();
		Path dir = this.root.resolve(type.getDirectory());
		if (!Files.isDirectory(dir)) {
			return namespaces;
		}
		try (Stream<Path> stream = Files.list(dir)) {
			stream.filter(Files::isDirectory).forEach(path -> namespaces.add(path.getFileName().toString()));
		} catch (IOException ignored) {
		}
		return namespaces;
	}

	@Override
	public Collection<ResourceLocation> getResources(PackType type, String namespace, String path, int maxDepth, Predicate<String> filter) {
		Set<ResourceLocation> found = new HashSet<>();
		Path base = this.resolve(type.getDirectory() + "/" + namespace + "/" + path);
		if (!Files.exists(base)) {
			return found;
		}
		try (Stream<Path> stream = Files.walk(base, maxDepth)) {
			stream.filter(Files::isRegularFile).forEach(file -> {
				String name = file.getFileName().toString();
				if (filter.test(name)) {
					String relative = base.relativize(file).toString().replace('\\', '/');
					String full = path.isEmpty() ? relative : path + "/" + relative;
					found.add(new ResourceLocation(namespace, full));
				}
			});
		} catch (IOException ignored) {
		}
		return found;
	}

	@Override
	public <T> T getMetadataSection(MetadataSectionSerializer<T> serializer) throws IOException {
		try (InputStream stream = this.getRootResource("pack.mcmeta")) {
			return AbstractPackResources.getMetadataFromStream(serializer, stream);
		}
	}

	@Override
	public String getName() {
		return "ratlantis";
	}

	@Override
	public void close() {
	}
}
