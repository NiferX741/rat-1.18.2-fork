package com.github.alexthe666.rats.server.loot;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.GlobalLootModifierSerializer;
import net.minecraftforge.common.loot.LootModifier;
import net.minecraftforge.registries.ForgeRegistries;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GenericAddItemLootModifier extends LootModifier {

	private final Map<Item, Integer> items;
	private final boolean makeNewPool;

	public GenericAddItemLootModifier(LootItemCondition[] conditions, Map<Item, Integer> items, boolean makeNewPool) {
		super(conditions);
		this.items = items;
		this.makeNewPool = makeNewPool;
	}

	@Override
	protected @NotNull List<ItemStack> doApply(List<ItemStack> generatedLoot, LootContext context) {
		if (this.makeNewPool) {
			generatedLoot.clear();
			if (this.items.size() > 1) {
				int chosenEntry = context.getRandom().nextInt(this.items.size());
				Item chosenItem = new ArrayList<>(this.items.keySet()).get(chosenEntry);
				generatedLoot.add(new ItemStack(chosenItem, this.items.get(chosenItem)));
			} else {
				for (Map.Entry<Item, Integer> entry : this.items.entrySet()) {
					generatedLoot.add(new ItemStack(entry.getKey(), entry.getValue()));
				}
			}
		} else {
			for (Map.Entry<Item, Integer> entry : this.items.entrySet()) {
				generatedLoot.add(new ItemStack(entry.getKey(), entry.getValue()));
			}
		}
		return generatedLoot;
	}

	public static class Serializer extends GlobalLootModifierSerializer<GenericAddItemLootModifier> {
		@Override
		public GenericAddItemLootModifier read(ResourceLocation location, JsonObject object, LootItemCondition[] conditions) {
			Map<Item, Integer> items = new HashMap<>();
			JsonObject map = object.getAsJsonObject("items");
			for (Map.Entry<String, JsonElement> entry : map.entrySet()) {
				Item item = ForgeRegistries.ITEMS.getValue(new ResourceLocation(entry.getKey()));
				if (item != null) {
					items.put(item, entry.getValue().getAsInt());
				}
			}
			boolean replace = object.has("replacePool") && object.get("replacePool").getAsBoolean();
			return new GenericAddItemLootModifier(conditions, items, replace);
		}

		@Override
		public JsonObject write(GenericAddItemLootModifier instance) {
			JsonObject json = this.makeConditions(instance.conditions);
			JsonObject items = new JsonObject();
			for (Map.Entry<Item, Integer> entry : instance.items.entrySet()) {
				ResourceLocation key = ForgeRegistries.ITEMS.getKey(entry.getKey());
				if (key != null) {
					items.addProperty(key.toString(), entry.getValue());
				}
			}
			json.add("items", items);
			json.addProperty("replacePool", instance.makeNewPool);
			return json;
		}
	}
}
