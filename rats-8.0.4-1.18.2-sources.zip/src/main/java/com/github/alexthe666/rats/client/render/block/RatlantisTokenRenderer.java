package com.github.alexthe666.rats.client.render.block;

import java.util.Random;

import com.github.alexthe666.rats.registry.RatlantisBlockRegistry;
import com.github.alexthe666.rats.registry.RatsBlockRegistry;
import com.github.alexthe666.rats.server.block.ChunkyCheeseTokenBlock;
import com.github.alexthe666.rats.server.block.entity.RatlantisTokenBlockEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Vector3f;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.block.model.ItemTransforms;
import net.minecraft.world.item.ItemStack;
import com.mojang.math.Matrix4f;

public class RatlantisTokenRenderer implements BlockEntityRenderer<RatlantisTokenBlockEntity> {

	private static final float HALF_SQRT_3 = (float) (Math.sqrt(3.0D) / 2.0D);

	public RatlantisTokenRenderer(BlockEntityRendererProvider.Context context) {
	}

	@Override
	public void render(RatlantisTokenBlockEntity entity, float partialTicks, PoseStack stack, MultiBufferSource buffer, int light, int overlay) {
		float progress = 0;
		float f1;
		float f2 = 0;
		if (entity.getLevel() != null && entity.getLevel().getBlockState(entity.getBlockPos()).getBlock() instanceof ChunkyCheeseTokenBlock) {
			progress = entity.tickCount - 1 + partialTicks;

			for (f1 = entity.ratRotation - entity.ratRotationPrev; f1 >= (float) Math.PI; f1 -= ((float) Math.PI * 2F)) {
			}
			while (f1 < -(float) Math.PI) {
				f1 += ((float) Math.PI * 2F);
			}
			f2 = entity.ratRotationPrev + f1 * Minecraft.getInstance().getFrameTime();
		}
		stack.pushPose();
		stack.translate(0.5D, 0.5D, 0.5D);
		stack.pushPose();
		float upwardSpeed = Math.max(0, (progress - 150F) / 150F);
		stack.translate(0, Math.min(1.5D, upwardSpeed), 0);
		stack.pushPose();
		float tokenScale = 0.5F;
		float rotateSpeed = progress / 3F * progress / 3F;
		float masterRot = rotateSpeed - f2 * (180F / (float) Math.PI) - 90F;
		stack.scale(tokenScale, tokenScale, tokenScale);
		stack.mulPose(Vector3f.YP.rotationDegrees(masterRot));
		Minecraft.getInstance().getItemRenderer().renderStatic(new ItemStack(RatlantisBlockRegistry.CHUNKY_CHEESE_TOKEN.get()), ItemTransforms.TransformType.FIXED, light, overlay, stack, buffer, 0);
		stack.popPose();
		stack.pushPose();
		if (progress > 150) {
			float elapsedTime = (progress - 150) / 200.0F;
			float amplifier = 0.0F;
			if (elapsedTime > 0.8F) {
				amplifier = 0.2F;
			}

			Random random = new Random(432L);
			VertexConsumer consumer = buffer.getBuffer(RenderType.lightning());
			stack.pushPose();
			stack.translate(0.0D, 0.0D, -0.0D);
			stack.scale(0.2F, 0.8F, 0.2F);

			for (int i = 0; (float) i < (elapsedTime + elapsedTime * elapsedTime) / 2.0F * 10.0F; ++i) {
				stack.mulPose(Vector3f.XP.rotationDegrees(random.nextFloat() * 360.0F));
				stack.mulPose(Vector3f.YP.rotationDegrees(random.nextFloat() * 360.0F));
				stack.mulPose(Vector3f.ZP.rotationDegrees(random.nextFloat() * 360.0F));
				stack.mulPose(Vector3f.XP.rotationDegrees(random.nextFloat() * 360.0F));
				stack.mulPose(Vector3f.YP.rotationDegrees(random.nextFloat() * 360.0F));
				stack.mulPose(Vector3f.ZP.rotationDegrees(random.nextFloat() * 360.0F + elapsedTime * 90.0F));
				float yAngle = random.nextFloat() * 20.0F + 5.0F + amplifier * 2.0F;
				float xAngle = random.nextFloat() * 2.0F + 1.0F + amplifier * 2.0F;
				Matrix4f matrix = stack.last().pose();
				int alpha = (int) (255.0F * (1.0F - amplifier));
				vertex01(consumer, matrix, alpha);
				vertex2(consumer, matrix, yAngle, xAngle);
				vertex3(consumer, matrix, yAngle, xAngle);
				vertex01(consumer, matrix, alpha);
				vertex3(consumer, matrix, yAngle, xAngle);
				vertex4(consumer, matrix, yAngle, xAngle);
				vertex01(consumer, matrix, alpha);
				vertex4(consumer, matrix, yAngle, xAngle);
				vertex2(consumer, matrix, yAngle, xAngle);
			}

			stack.popPose();
		}
		stack.popPose();
		stack.pushPose();
		if (progress > 450) {
			float progMod = progress - 450;
			float blocksScale = Math.min(progMod / 50F, 2);
			stack.scale(blocksScale, blocksScale, blocksScale);
			stack.translate(0, 0, 0);
			stack.pushPose();
			stack.translate(0, 0.75F * blocksScale * 0.5F, 0);
			Minecraft.getInstance().getItemRenderer().renderStatic(new ItemStack(RatsBlockRegistry.MARBLED_CHEESE_RAW.get()), ItemTransforms.TransformType.FIXED, light, overlay, stack, buffer, 0);
			stack.popPose();
			stack.pushPose();
			stack.translate(0, 0.5 - 1.25F * blocksScale * 0.5F, 0);
			Minecraft.getInstance().getItemRenderer().renderStatic(new ItemStack(RatsBlockRegistry.MARBLED_CHEESE_RAW.get()), ItemTransforms.TransformType.FIXED, light, overlay, stack, buffer, 0);
			stack.popPose();

		}
		stack.popPose();
		stack.popPose();
		stack.popPose();
	}

	private static void vertex01(VertexConsumer consumer, Matrix4f matrix, int alpha) {
		consumer.vertex(matrix, 0.0F, 0.0F, 0.0F).color(255, 255, 255, alpha).endVertex();
		consumer.vertex(matrix, 0.0F, 0.0F, 0.0F).color(255, 255, 255, alpha).endVertex();
	}

	private static void vertex2(VertexConsumer consumer, Matrix4f matrix, float y, float x) {
		consumer.vertex(matrix, -HALF_SQRT_3 * x, y, -0.5F * x).color(255, 169, 33, 0).endVertex();
	}

	private static void vertex3(VertexConsumer consumer, Matrix4f matrix, float y, float x) {
		consumer.vertex(matrix, HALF_SQRT_3 * x, y, -0.5F * x).color(255, 169, 33, 0).endVertex();
	}

	private static void vertex4(VertexConsumer consumer, Matrix4f matrix, float y, float x) {
		consumer.vertex(matrix, 0.0F, y, x).color(255, 169, 33, 0).endVertex();
	}
}
