package com.github.alexthe666.rats.server.items.upgrades;

import com.github.alexthe666.rats.server.entity.rat.TamedRat;
import com.github.alexthe666.rats.server.items.upgrades.interfaces.DamageImmunityUpgrade;
import net.minecraft.world.damagesource.DamageSource;

public class PoisonRatUpgradeItem extends BaseRatUpgradeItem implements DamageImmunityUpgrade {
	public PoisonRatUpgradeItem(Properties properties) {
		super(properties, 0, 4);
	}

	@Override
	public boolean isImmuneToDamageSource(TamedRat rat, DamageSource source) {
		return source == DamageSource.DROWN || source.isMagic() || source == DamageSource.WITHER;
	}
}
