package com.github.alexthe666.rats.registry;

import com.github.alexthe666.rats.RatsMod;
import com.github.alexthe666.rats.client.events.ModClientEvents;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraftforge.common.Tags;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraft.core.NonNullList;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class RatsCreativeTabRegistry {

	public static final CreativeModeTab RATS = new CreativeModeTab("rats.rats") {
		@Override
		public ItemStack makeIcon() {
			return new ItemStack(RatsItemRegistry.CHEESE.get());
		}

		@Override
		public void fillItemList(NonNullList<ItemStack> items) {
			accept(items, RatsItemRegistry.CHEESE.get());
			accept(items, RatsItemRegistry.BLUE_CHEESE.get());
			accept(items, RatsItemRegistry.NETHER_CHEESE.get());
			accept(items, RatsBlockRegistry.BLOCK_OF_CHEESE.get());
			accept(items, RatsBlockRegistry.BLOCK_OF_BLUE_CHEESE.get());
			accept(items, RatsBlockRegistry.BLOCK_OF_NETHER_CHEESE.get());
			accept(items, RatsBlockRegistry.RAT_TRAP.get());
			accept(items, RatsBlockRegistry.AUTO_CURDLER.get());
			accept(items, RatsBlockRegistry.RAT_CRAFTING_TABLE.get());
			accept(items, RatsItemRegistry.RAW_RAT.get());
			accept(items, RatsItemRegistry.COOKED_RAT.get());
			accept(items, RatsItemRegistry.RAT_PELT.get());
			accept(items, RatsItemRegistry.RAT_PAW.get());
			accept(items, RatsItemRegistry.RAT_SKULL.get());
			accept(items, RatsItemRegistry.GOLDEN_RAT_SKULL.get());
			accept(items, RatsItemRegistry.CORRUPT_RAT_SKULL.get());
			accept(items, RatsItemRegistry.TANGLED_RAT_TAILS.get());
			accept(items, RatsItemRegistry.RAT_ARROW.get());
			accept(items, RatsBlockRegistry.TRASH_CAN.get());
			accept(items, RatsBlockRegistry.GARBAGE_PILE.get());
			accept(items, RatsBlockRegistry.CURSED_GARBAGE.get());
			accept(items, RatsBlockRegistry.PURIFIED_GARBAGE.get());
			accept(items, RatsBlockRegistry.PIED_GARBAGE.get());
			accept(items, RatsBlockRegistry.COMPRESSED_GARBAGE.get());
			accept(items, RatsItemRegistry.FILTH.get());
			accept(items, RatsItemRegistry.FILTH_CORRUPTION.get());
			accept(items, RatsItemRegistry.CONTAMINATED_FOOD.get());
			accept(items, RatsItemRegistry.STRING_CHEESE.get());
			accept(items, RatsItemRegistry.RAT_BURGER.get());
			accept(items, RatsItemRegistry.ASSORTED_VEGETABLES.get());
			accept(items, RatsItemRegistry.CONFIT_BYALDI.get());
			accept(items, RatsItemRegistry.POTATO_PANCAKE.get());
			accept(items, RatsItemRegistry.LITTLE_BLACK_SQUASH_BALLS.get());
			accept(items, RatsItemRegistry.LITTLE_BLACK_WORM.get());
			accept(items, RatsItemRegistry.CENTIPEDE.get());
			accept(items, RatsItemRegistry.POTATO_KNISHES.get());
			accept(items, RatsItemRegistry.HERB_BUNDLE.get());
			accept(items, RatsItemRegistry.TREACLE.get());
			accept(items, RatsItemRegistry.PLAGUE_LEECH.get());
			accept(items, RatsItemRegistry.PLAGUE_STEW.get());
			accept(items, RatsItemRegistry.PLAGUE_DOCTORATE.get());
			accept(items, RatsItemRegistry.PLAGUE_TOME.get());
			accept(items, RatsItemRegistry.PLAGUE_ESSENCE.get());
			accept(items, RatsItemRegistry.PURIFYING_LIQUID.get());
			accept(items, RatsItemRegistry.CRIMSON_FLUID.get());
			accept(items, RatsItemRegistry.CHEF_TOQUE.get());
			accept(items, RatsItemRegistry.PIPER_HAT.get());
			accept(items, RatsItemRegistry.ARCHEOLOGIST_HAT.get());
			accept(items, RatsItemRegistry.FARMER_HAT.get());
			accept(items, RatsItemRegistry.FISHERMAN_HAT.get());
			accept(items, RatsItemRegistry.RAT_FEZ.get());
			accept(items, RatsItemRegistry.TOP_HAT.get());
			accept(items, RatsItemRegistry.SANTA_HAT.get());
			accept(items, RatsItemRegistry.HALO_HAT.get());
			accept(items, RatsItemRegistry.PARTY_HAT.get());
			accept(items, RatsItemRegistry.PIRAT_HAT.get());
			accept(items, RatsItemRegistry.RAT_KING_CROWN.get());
			accept(items, RatsItemRegistry.PLAGUE_DOCTOR_MASK.get());
			accept(items, RatsItemRegistry.BLACK_DEATH_MASK.get());
			accept(items, RatsItemRegistry.EXTERMINATOR_HAT.get());
			accept(items, RatsItemRegistry.CHEESE_STICK.get());
			accept(items, RatsItemRegistry.RADIUS_STICK.get());
			accept(items, RatsItemRegistry.PATROL_STICK.get());
			accept(items, RatsItemRegistry.RAT_WHISTLE.get());
			accept(items, RatsItemRegistry.RAT_FLUTE.get());
			accept(items, RatsItemRegistry.GILDED_RAT_FLUTE.get());
			accept(items, RatsItemRegistry.PLAGUE_SCYTHE.get());
			accept(items, RatsItemRegistry.MUSIC_DISC_MICE_ON_VENUS.get());
			accept(items, RatsItemRegistry.MUSIC_DISC_LIVING_MICE.get());
			accept(items, RatsBlockRegistry.RAT_CAGE.get());
			accept(items, RatsItemRegistry.PLASTIC_WASTE.get());
			accept(items, RatsItemRegistry.RAW_PLASTIC.get());
			accept(items, RatsItemRegistry.RAT_BREEDING_LANTERN.get());
			accept(items, RatsItemRegistry.RAT_SEED_BOWL.get());
			accept(items, RatsItemRegistry.RAT_WATER_BOTTLE.get());
			accept(items, RatsItemRegistry.RAT_WHEEL.get());
			registerColoredItems(items, "rat_tube");
			registerColoredItems(items, "rat_igloo");
			registerColoredItems(items, "rat_hammock");
			accept(items, RatsItemRegistry.RAT_CAPTURE_NET.get());
			accept(items, RatsItemRegistry.RAT_SACK.get());
			accept(items, RatsItemRegistry.FEATHERY_WING.get());
			accept(items, RatsItemRegistry.DRAGON_WING.get());
			accept(items, RatsItemRegistry.CHARGED_CREEPER_CHUNK.get());
			accept(items, RatsItemRegistry.RATBOW_ESSENCE.get());
			accept(items, RatsItemRegistry.RAT_PAPERS.get());
			accept(items, RatsItemRegistry.TINY_COIN.get());
			accept(items, RatsItemRegistry.TOKEN_FRAGMENT.get());
			accept(items, RatsItemRegistry.TOKEN_PIECE.get());
			accept(items, RatsBlockRegistry.MARBLED_CHEESE_RAW.get());
			accept(items, RatsBlockRegistry.FISH_BARREL.get());
			accept(items, RatsBlockRegistry.DYE_SPONGE.get());
			accept(items, RatsBlockRegistry.PIED_WOOL.get());
			accept(items, RatsBlockRegistry.JACK_O_RATERN.get());
			accept(items, RatsBlockRegistry.UPGRADE_COMBINER.get());
			accept(items, RatsBlockRegistry.UPGRADE_SEPARATOR.get());
			accept(items, RatsBlockRegistry.MANHOLE.get());
			accept(items, RatsBlockRegistry.RAT_QUARRY.get());
			accept(items, RatsBlockRegistry.RAT_ATTRACTOR.get());
			accept(items, RatsBlockRegistry.RAT_UPGRADE_BLOCK.get());
			accept(items, RatsItemRegistry.RAT_BANNER_PATTERN.get());
			accept(items, RatsItemRegistry.CHEESE_BANNER_PATTERN.get());
			accept(items, RatsItemRegistry.RAC_BANNER_PATTERN.get());
			accept(items, Objects.requireNonNull(ForgeRegistries.ITEMS.getValue(new ResourceLocation(RatsMod.MODID, "rat_spawn_egg"))));
			accept(items, Objects.requireNonNull(ForgeRegistries.ITEMS.getValue(new ResourceLocation(RatsMod.MODID, "demon_rat_spawn_egg"))));
			accept(items, Objects.requireNonNull(ForgeRegistries.ITEMS.getValue(new ResourceLocation(RatsMod.MODID, "rat_king_spawn_egg"))));
			accept(items, Objects.requireNonNull(ForgeRegistries.ITEMS.getValue(new ResourceLocation(RatsMod.MODID, "pied_piper_spawn_egg"))));
			accept(items, Objects.requireNonNull(ForgeRegistries.ITEMS.getValue(new ResourceLocation(RatsMod.MODID, "plague_doctor_spawn_egg"))));
			accept(items, Objects.requireNonNull(ForgeRegistries.ITEMS.getValue(new ResourceLocation(RatsMod.MODID, "black_death_spawn_egg"))));
			accept(items, Objects.requireNonNull(ForgeRegistries.ITEMS.getValue(new ResourceLocation(RatsMod.MODID, "plague_cloud_spawn_egg"))));
			accept(items, Objects.requireNonNull(ForgeRegistries.ITEMS.getValue(new ResourceLocation(RatsMod.MODID, "plague_beast_spawn_egg"))));
			registerOreNuggets(items);
			accept(items, RatsItemRegistry.CREATIVE_CHEESE.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_CREATIVE.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_COMBINED_CREATIVE.get());
		}
	};

	public static final CreativeModeTab UPGRADES = new CreativeModeTab("rats.upgrades") {
		@Override
		public ItemStack makeIcon() {
			return new ItemStack(RatsItemRegistry.RAT_UPGRADE_BASIC.get());
		}

		@Override
		public void fillItemList(NonNullList<ItemStack> items) {
			accept(items, RatsItemRegistry.RAT_UPGRADE_BASIC.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_SPEED.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_HEALTH.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_ARMOR.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_STRENGTH.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_WARRIOR.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_GOD.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_BOW.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_CROSSBOW.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_AQUATIC.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_FLIGHT.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_DRAGON.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_BEE.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_DEMON.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_ENDER.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_UNDEAD.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_CARRAT.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_NO_FLUTE.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_ANGEL.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_ASBESTOS.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_POISON.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_UNDERWATER.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_DAMAGE_PROTECTION.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_TNT.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_TNT_SURVIVOR.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_ARISTOCRAT.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_VOODOO.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_BREEDER.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_FISHERMAN.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_LUMBERJACK.get());
			//accept(items, RatsItemRegistry.RAT_UPGRADE_MINER_ORE.get());
			//accept(items, RatsItemRegistry.RAT_UPGRADE_MINER.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_FARMER.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_QUARRY.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_REPLANTER.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_SHEARS.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_DISENCHANTER.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_ENCHANTER.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_PLACER.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_CRAFTING.get());
			accept(items, RatlantisItemRegistry.RAT_UPGRADE_ARCHEOLOGIST.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_CHEF.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_GEMCUTTER.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_CHRISTMAS.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_ORE_DOUBLING.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_BUCKET.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_BIG_BUCKET.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_MILKER.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_BASIC_ENERGY.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_ADVANCED_ENERGY.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_ELITE_ENERGY.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_EXTREME_ENERGY.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_BLACKLIST.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_WHITELIST.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_TICK_ACCELERATOR.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_PLATTER.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_BASIC_MOUNT.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_CHICKEN_MOUNT.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_GOLEM_MOUNT.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_STRIDER_MOUNT.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_BEAST_MOUNT.get());
			accept(items, RatlantisItemRegistry.RAT_UPGRADE_AUTOMATON_MOUNT.get());
			accept(items, RatlantisItemRegistry.RAT_UPGRADE_BIPLANE_MOUNT.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_JURY_RIGGED.get());
			accept(items, RatsItemRegistry.RAT_UPGRADE_COMBINED.get());
			accept(items, RatlantisItemRegistry.RAT_UPGRADE_BASIC_RATLANTEAN.get());
			accept(items, RatlantisItemRegistry.RAT_UPGRADE_FERAL_BITE.get());
			accept(items, RatlantisItemRegistry.RAT_UPGRADE_BUCCANEER.get());
			accept(items, RatlantisItemRegistry.RAT_UPGRADE_RATINATOR.get());
			accept(items, RatlantisItemRegistry.RAT_UPGRADE_PSYCHIC.get());
			accept(items, RatlantisItemRegistry.RAT_UPGRADE_ETHEREAL.get());
			accept(items, RatlantisItemRegistry.RAT_UPGRADE_NONBELIEVER.get());
		}
	};

	public static final CreativeModeTab RATLANTIS = new CreativeModeTab("rats.ratlantis") {
		@Override
		public ItemStack makeIcon() {
			return new ItemStack(RatlantisBlockRegistry.CHUNKY_CHEESE_TOKEN.get());
		}

		@Override
		public void fillItemList(NonNullList<ItemStack> items) {
			accept(items, RatlantisBlockRegistry.CHUNKY_CHEESE_TOKEN.get());
			accept(items, RatlantisBlockRegistry.RATGLOVE_FLOWER.get());
			accept(items, RatlantisItemRegistry.RATGLOVE_PETALS.get());
			accept(items, RatlantisItemRegistry.FERAL_RAT_CLAW.get());
			accept(items, RatlantisItemRegistry.RATLANTEAN_FLAME.get());
			accept(items, RatlantisItemRegistry.GEM_OF_RATLANTIS.get());
			accept(items, RatlantisItemRegistry.RAW_ORATCHALCUM.get());
			accept(items, RatlantisItemRegistry.ORATCHALCUM_NUGGET.get());
			accept(items, RatlantisItemRegistry.ORATCHALCUM_INGOT.get());
			accept(items, RatlantisItemRegistry.RATLANTIS_HELMET.get());
			accept(items, RatlantisItemRegistry.RATLANTIS_CHESTPLATE.get());
			accept(items, RatlantisItemRegistry.RATLANTIS_LEGGINGS.get());
			accept(items, RatlantisItemRegistry.RATLANTIS_BOOTS.get());
			accept(items, RatlantisItemRegistry.RATLANTIS_SWORD.get());
			accept(items, RatlantisItemRegistry.RATLANTIS_SHOVEL.get());
			accept(items, RatlantisItemRegistry.RATLANTIS_PICKAXE.get());
			accept(items, RatlantisItemRegistry.RATLANTIS_AXE.get());
			accept(items, RatlantisItemRegistry.RATLANTIS_HOE.get());
			accept(items, RatlantisItemRegistry.RATLANTIS_BOW.get());
			accept(items, RatlantisItemRegistry.FERAL_BAGH_NAKHS.get());
			accept(items, RatlantisItemRegistry.PIRAT_CUTLASS.get());
			accept(items, RatlantisItemRegistry.GHOST_PIRAT_CUTLASS.get());
			accept(items, RatlantisItemRegistry.AVIATOR_HAT.get());
			accept(items, RatlantisItemRegistry.GHOST_PIRAT_HAT.get());
			accept(items, RatlantisItemRegistry.MILITARY_HAT.get());
			accept(items, RatlantisItemRegistry.RAT_TOGA.get());
			accept(items, RatlantisBlockRegistry.MARBLED_CHEESE_RAT_HEAD.get());
			accept(items, RatlantisItemRegistry.CHEESE_CANNONBALL.get());
			accept(items, RatlantisItemRegistry.RATBOT_BARREL.get());
			accept(items, RatlantisItemRegistry.CHARGED_RATBOT_BARREL.get());
			accept(items, RatlantisItemRegistry.GHOST_PIRAT_ECTOPLASM.get());
			accept(items, RatlantisItemRegistry.RATFISH.get());
			accept(items, RatlantisItemRegistry.RATFISH_BUCKET.get());
			accept(items, RatlantisItemRegistry.RATTLING_GUN.get());
			accept(items, RatlantisItemRegistry.VIAL_OF_SENTIENCE.get());
			accept(items, RatlantisItemRegistry.RAS_BANNER_PATTERN.get());
			accept(items, RatlantisBlockRegistry.DUTCHRAT_BELL.get());
			accept(items, RatlantisBlockRegistry.AIR_RAID_SIREN.get());
			accept(items, RatlantisItemRegistry.ARCANE_TECHNOLOGY.get());
			accept(items, RatlantisItemRegistry.ANCIENT_SAWBLADE.get());
			accept(items, RatlantisItemRegistry.PSIONIC_RAT_BRAIN.get());
			accept(items, RatlantisItemRegistry.DUTCHRAT_WHEEL.get());
			accept(items, RatlantisItemRegistry.BIPLANE_WING.get());
			accept(items, RatlantisItemRegistry.RATLANTIS_RAT_SKULL.get());
			accept(items, RatlantisItemRegistry.IDOL_OF_RATLANTIS.get());
			accept(items, RatlantisBlockRegistry.CHEESE_ORE.get());
			accept(items, RatlantisBlockRegistry.RATLANTEAN_GEM_ORE.get());
			accept(items, RatlantisBlockRegistry.ORATCHALCUM_ORE.get());
			accept(items, RatlantisBlockRegistry.ORATCHALCUM_BLOCK.get());
			accept(items, RatlantisBlockRegistry.BRAIN_BLOCK.get());
			accept(items, RatlantisBlockRegistry.COMPRESSED_RAT.get());
			accept(items, RatlantisBlockRegistry.RATLANTIS_UPGRADE_BLOCK.get());
			accept(items, RatlantisBlockRegistry.MARBLED_CHEESE.get());
			accept(items, RatlantisBlockRegistry.MARBLED_CHEESE_STAIRS.get());
			accept(items, RatlantisBlockRegistry.MARBLED_CHEESE_SLAB.get());
			accept(items, RatlantisBlockRegistry.MARBLED_CHEESE_BRICK.get());
			accept(items, RatlantisBlockRegistry.MARBLED_CHEESE_BRICK_STAIRS.get());
			accept(items, RatlantisBlockRegistry.MARBLED_CHEESE_BRICK_SLAB.get());
			accept(items, RatlantisBlockRegistry.MARBLED_CHEESE_BRICK_CRACKED.get());
			accept(items, RatlantisBlockRegistry.MARBLED_CHEESE_BRICK_CRACKED_STAIRS.get());
			accept(items, RatlantisBlockRegistry.MARBLED_CHEESE_BRICK_CRACKED_SLAB.get());
			accept(items, RatlantisBlockRegistry.MARBLED_CHEESE_BRICK_MOSSY.get());
			accept(items, RatlantisBlockRegistry.MARBLED_CHEESE_BRICK_MOSSY_STAIRS.get());
			accept(items, RatlantisBlockRegistry.MARBLED_CHEESE_BRICK_MOSSY_SLAB.get());
			accept(items, RatlantisBlockRegistry.MARBLED_CHEESE_CHISELED.get());
			accept(items, RatlantisBlockRegistry.MARBLED_CHEESE_BRICK_CHISELED.get());
			accept(items, RatlantisBlockRegistry.MARBLED_CHEESE_PILLAR.get());
			accept(items, RatlantisBlockRegistry.MARBLED_CHEESE_TILE.get());
			accept(items, RatlantisBlockRegistry.MARBLED_CHEESE_GOLEM_CORE.get());
			accept(items, RatlantisBlockRegistry.BLACK_MARBLED_CHEESE.get());
			accept(items, RatlantisBlockRegistry.MARBLED_CHEESE_GRASS.get());
			accept(items, RatlantisBlockRegistry.MARBLED_CHEESE_DIRT.get());
			accept(items, RatlantisBlockRegistry.PIRAT_LOG.get());
			accept(items, RatlantisBlockRegistry.PIRAT_WOOD.get());
			accept(items, RatlantisBlockRegistry.STRIPPED_PIRAT_LOG.get());
			accept(items, RatlantisBlockRegistry.STRIPPED_PIRAT_WOOD.get());
			accept(items, RatlantisBlockRegistry.PIRAT_PLANKS.get());
			accept(items, RatlantisBlockRegistry.PIRAT_STAIRS.get());
			accept(items, RatlantisBlockRegistry.PIRAT_SLAB.get());
			accept(items, RatlantisBlockRegistry.PIRAT_FENCE.get());
			accept(items, RatlantisBlockRegistry.PIRAT_FENCE_GATE.get());
			accept(items, RatlantisBlockRegistry.PIRAT_DOOR.get());
			accept(items, RatlantisBlockRegistry.PIRAT_TRAPDOOR.get());
			accept(items, RatlantisBlockRegistry.PIRAT_PRESSURE_PLATE.get());
			accept(items, RatlantisBlockRegistry.PIRAT_BUTTON.get());
			accept(items, Objects.requireNonNull(ForgeRegistries.ITEMS.getValue(new ResourceLocation(RatsMod.MODID, "feral_ratlantean_spawn_egg"))));
			accept(items, Objects.requireNonNull(ForgeRegistries.ITEMS.getValue(new ResourceLocation(RatsMod.MODID, "ratlantean_spirit_spawn_egg"))));
			accept(items, Objects.requireNonNull(ForgeRegistries.ITEMS.getValue(new ResourceLocation(RatsMod.MODID, "pirat_spawn_egg"))));
			accept(items, Objects.requireNonNull(ForgeRegistries.ITEMS.getValue(new ResourceLocation(RatsMod.MODID, "ghost_pirat_spawn_egg"))));
			accept(items, Objects.requireNonNull(ForgeRegistries.ITEMS.getValue(new ResourceLocation(RatsMod.MODID, "ratfish_spawn_egg"))));
			accept(items, Objects.requireNonNull(ForgeRegistries.ITEMS.getValue(new ResourceLocation(RatsMod.MODID, "ratlantean_ratbot_spawn_egg"))));
			accept(items, Objects.requireNonNull(ForgeRegistries.ITEMS.getValue(new ResourceLocation(RatsMod.MODID, "ratlantean_automaton_spawn_egg"))));
			accept(items, Objects.requireNonNull(ForgeRegistries.ITEMS.getValue(new ResourceLocation(RatsMod.MODID, "neo_ratlantean_spawn_egg"))));
			accept(items, Objects.requireNonNull(ForgeRegistries.ITEMS.getValue(new ResourceLocation(RatsMod.MODID, "dutchrat_spawn_egg"))));
			accept(items, Objects.requireNonNull(ForgeRegistries.ITEMS.getValue(new ResourceLocation(RatsMod.MODID, "rat_baron_spawn_egg"))));
		}
	};

	public static void init() {
		// Class init registers the tabs with Forge.
	}

	private static void accept(NonNullList<ItemStack> items, ItemLike item) {
		if (item != null) {
			items.add(new ItemStack(item));
		}
	}

	private static void accept(NonNullList<ItemStack> items, ItemStack stack) {
		if (stack != null && !stack.isEmpty()) {
			items.add(stack);
		}
	}

	private static void registerOreNuggets(NonNullList<ItemStack> items) {
		accept(items, RatsItemRegistry.RAT_NUGGET.get());
		List<ItemStack> uniqueOres = new ArrayList<>();
		for (Item item : ForgeRegistries.ITEMS.tags().getTag(Tags.Items.ORES)) {
			ItemStack oreDrop = ModClientEvents.getIngotHereBecauseClassloading(item.getDefaultInstance());
			if (!uniqueOres.contains(oreDrop) && !oreDrop.isEmpty()) {
				uniqueOres.add(oreDrop);
			}
		}
		for (ItemStack ore : uniqueOres) {
			accept(items, ModClientEvents.saveIngotHereBecauseClassloading(ore));
		}
	}

	private static void registerColoredItems(NonNullList<ItemStack> items, String itemType) {
		for (DyeColor color : DyeColor.values()) {
			Item item = ForgeRegistries.ITEMS.getValue(new ResourceLocation(RatsMod.MODID, itemType + "_" + color.getName()));
			if (item != null) {
				items.add(new ItemStack(item));
			}
		}
	}
}
