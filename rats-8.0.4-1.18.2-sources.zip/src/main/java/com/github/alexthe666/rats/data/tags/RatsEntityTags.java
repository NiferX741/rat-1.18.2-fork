package com.github.alexthe666.rats.data.tags;

import com.github.alexthe666.rats.RatsMod;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;

public class RatsEntityTags {
	public static final TagKey<EntityType<?>> RATS = create("rats");
	public static final TagKey<EntityType<?>> RAT_MOUNTS = create("rat_mounts");
	public static final TagKey<EntityType<?>> PLAGUE_IMMUNE = create("plague_immune");
	public static final TagKey<EntityType<?>> PLAGUE_LEGION = create("plague_legion");

	public static TagKey<EntityType<?>> create(String name) {
		return TagKey.create(Registry.ENTITY_TYPE_REGISTRY, new ResourceLocation(RatsMod.MODID, name));
	}
}
