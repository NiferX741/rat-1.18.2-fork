package com.github.alexthe666.rats.registry;

import com.github.alexthe666.rats.RatsMod;
import com.github.alexthe666.rats.server.recipes.ArcheologistRecipe;
import com.github.alexthe666.rats.server.recipes.ChefRecipe;
import com.github.alexthe666.rats.server.recipes.GemcutterRecipe;
import com.github.alexthe666.rats.server.recipes.RatsRecipeSerializer;
import net.minecraft.core.Registry;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class RatsRecipeRegistry {

	public static final DeferredRegister<RecipeType<?>> RECIPES = DeferredRegister.create(Registry.RECIPE_TYPE_REGISTRY, RatsMod.MODID);
	public static final DeferredRegister<RecipeSerializer<?>> SERIALIZERS = DeferredRegister.create(ForgeRegistries.RECIPE_SERIALIZERS, RatsMod.MODID);

	public static final RegistryObject<RecipeType<ArcheologistRecipe>> ARCHEOLOGIST = RECIPES.register("archeologist", () -> simple("rats:archeologist"));
	public static final RegistryObject<RecipeSerializer<ArcheologistRecipe>> ARCHEOLOGIST_SERIALIZER = SERIALIZERS.register("archeologist", () -> new RatsRecipeSerializer<>(ArcheologistRecipe::new));
	public static final RegistryObject<RecipeType<ChefRecipe>> CHEF = RECIPES.register("chef", () -> simple("rats:chef"));
	public static final RegistryObject<RecipeSerializer<ChefRecipe>> CHEF_SERIALIZER = SERIALIZERS.register("chef", () -> new RatsRecipeSerializer<>(ChefRecipe::new));
	public static final RegistryObject<RecipeType<GemcutterRecipe>> GEMCUTTER = RECIPES.register("gemcutter", () -> simple("rats:gemcutter"));
	public static final RegistryObject<RecipeSerializer<GemcutterRecipe>> GEMCUTTER_SERIALIZER = SERIALIZERS.register("gemcutter", () -> new RatsRecipeSerializer<>(GemcutterRecipe::new));

	private static <T extends Recipe<?>> RecipeType<T> simple(String id) {
		return new RecipeType<>() {
			@Override
			public String toString() {
				return id;
			}
		};
	}
}
