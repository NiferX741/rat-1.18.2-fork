package com.github.alexthe666.rats.data.tags;

import com.github.alexthe666.rats.RatsMod;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.Block;

public class RatsBlockTags {
	public static final TagKey<Block> MARBLED_CHEESE = TagKey.create(net.minecraft.core.Registry.BLOCK_REGISTRY, new ResourceLocation("rats:marbled_cheese"));

	public static final TagKey<Block> TRASH_CAN_BLACKLIST = TagKey.create(net.minecraft.core.Registry.BLOCK_REGISTRY, new ResourceLocation("rats:trash_can_blacklist"));

	public static final TagKey<Block> QUARRY_IGNORABLES = TagKey.create(net.minecraft.core.Registry.BLOCK_REGISTRY, new ResourceLocation("rats:quarry_ignoreables"));

	public static final TagKey<Block> UNRAIDABLE_CONTAINERS = TagKey.create(net.minecraft.core.Registry.BLOCK_REGISTRY, new ResourceLocation("rats:unraidable_containers"));

	public static final TagKey<Block> DIGGABLE_BLOCKS = TagKey.create(net.minecraft.core.Registry.BLOCK_REGISTRY, new ResourceLocation("rats:diggable_blocks"));

	public static final TagKey<Block> STORAGE_BLOCKS_CHEESE = TagKey.create(net.minecraft.core.Registry.BLOCK_REGISTRY, new ResourceLocation("forge:storage_blocks/cheese"));

	public static final TagKey<Block> STORAGE_BLOCKS_BLUE_CHEESE = TagKey.create(net.minecraft.core.Registry.BLOCK_REGISTRY, new ResourceLocation("forge:storage_blocks/blue_cheese"));

	public static final TagKey<Block> STORAGE_BLOCKS_NETHER_CHEESE = TagKey.create(net.minecraft.core.Registry.BLOCK_REGISTRY, new ResourceLocation("forge:storage_blocks/nether_cheese"));

	public static final TagKey<Block> CRAFTING_TABLES = TagKey.create(net.minecraft.core.Registry.BLOCK_REGISTRY, new ResourceLocation("forge:crafting_tables"));
}
