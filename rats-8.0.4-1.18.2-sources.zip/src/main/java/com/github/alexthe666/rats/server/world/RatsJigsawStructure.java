package com.github.alexthe666.rats.server.world;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.StructureFeature;
import net.minecraft.world.level.levelgen.feature.configurations.JigsawConfiguration;
import net.minecraft.world.level.levelgen.structure.PoolElementStructurePiece;
import net.minecraft.world.level.levelgen.structure.pools.JigsawPlacement;

public class RatsJigsawStructure extends StructureFeature<JigsawConfiguration> {
	public RatsJigsawStructure(Heightmap.Types heightmap) {
		super(JigsawConfiguration.CODEC, context -> {
			ChunkPos chunk = context.chunkPos();
			int x = chunk.getMinBlockX();
			int z = chunk.getMinBlockZ();
			int y = context.chunkGenerator().getFirstFreeHeight(x, z, heightmap, context.heightAccessor());
			return JigsawPlacement.addPieces(context, PoolElementStructurePiece::new, new BlockPos(x, y, z), false, false);
		});
	}

	@Override
	public GenerationStep.Decoration step() {
		return GenerationStep.Decoration.SURFACE_STRUCTURES;
	}
}
