package com.github.alexthe666.rats.data.tags;

import com.github.alexthe666.rats.RatsMod;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;

public class RatsItemTags {
	public static final TagKey<Item> CHEESE_ITEMS = TagKey.create(net.minecraft.core.Registry.ITEM_REGISTRY, new ResourceLocation("forge:cheeses"));

	public static final TagKey<Item> NORMAL_CHEESE = TagKey.create(net.minecraft.core.Registry.ITEM_REGISTRY, new ResourceLocation("forge:cheeses/normal"));

	public static final TagKey<Item> BLUE_CHEESE = TagKey.create(net.minecraft.core.Registry.ITEM_REGISTRY, new ResourceLocation("forge:cheeses/blue"));

	public static final TagKey<Item> NETHER_CHEESE = TagKey.create(net.minecraft.core.Registry.ITEM_REGISTRY, new ResourceLocation("forge:cheeses/nether"));

	public static final TagKey<Item> CRAFTING_TABLES = TagKey.create(net.minecraft.core.Registry.ITEM_REGISTRY, new ResourceLocation("forge:crafting_tables"));

	public static final TagKey<Item> VEGETABLES = TagKey.create(net.minecraft.core.Registry.ITEM_REGISTRY, new ResourceLocation("forge:vegetables"));

	public static final TagKey<Item> PLASTICS = TagKey.create(net.minecraft.core.Registry.ITEM_REGISTRY, new ResourceLocation("forge:plastics"));

	public static final TagKey<Item> IGLOOS = TagKey.create(net.minecraft.core.Registry.ITEM_REGISTRY, new ResourceLocation("rats:igloos"));

	public static final TagKey<Item> TUBES = TagKey.create(net.minecraft.core.Registry.ITEM_REGISTRY, new ResourceLocation("rats:tubes"));

	public static final TagKey<Item> HAMMOCKS = TagKey.create(net.minecraft.core.Registry.ITEM_REGISTRY, new ResourceLocation("rats:hammocks"));

	public static final TagKey<Item> MARBLED_CHEESE = TagKey.create(net.minecraft.core.Registry.ITEM_REGISTRY, new ResourceLocation("rats:marbled_cheese"));

	public static final TagKey<Item> STORAGE_BLOCKS_CHEESE = TagKey.create(net.minecraft.core.Registry.ITEM_REGISTRY, new ResourceLocation("forge:storage_blocks/cheese"));

	public static final TagKey<Item> STORAGE_BLOCKS_BLUE_CHEESE = TagKey.create(net.minecraft.core.Registry.ITEM_REGISTRY, new ResourceLocation("forge:storage_blocks/blue_cheese"));

	public static final TagKey<Item> STORAGE_BLOCKS_NETHER_CHEESE = TagKey.create(net.minecraft.core.Registry.ITEM_REGISTRY, new ResourceLocation("forge:storage_blocks/nether_cheese"));
}
