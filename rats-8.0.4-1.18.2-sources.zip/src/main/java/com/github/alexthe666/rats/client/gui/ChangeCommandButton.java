package com.github.alexthe666.rats.client.gui;

import net.minecraft.network.chat.TextComponent;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

public class ChangeCommandButton extends Button {
	private final boolean right;

	public ChangeCommandButton(int x, int y, boolean right, Button.OnPress onPress) {
		super(x, y, 7, 11, new TextComponent(""), onPress, Button.NO_TOOLTIP);
		this.right = right;
	}

	@Override
	public void render(PoseStack matrixStack, int mouseX, int mouseY, float partialTicks) {
		if (this.visible) {
			boolean flag = mouseX >= this.x && mouseY >= this.y && mouseX < this.x + this.width && mouseY < this.y + this.height;
			RenderSystem.setShaderTexture(0, RatScreen.TEXTURE);
			RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
			int i = 0;
			int j = 166;
			if (flag) {
				i += 14;
			}
			if (this.right) {
				i += 7;
			}
			blit(matrixStack, this.x, this.y, i, j, this.width, this.height);
		}
	}
}
